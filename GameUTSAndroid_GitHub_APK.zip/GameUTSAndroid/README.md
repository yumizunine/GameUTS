# Game Belajar UTS - Android

Proyek Android Studio untuk Game Belajar UTS 8 Mata Kuliah.

## Cara membuat APK
1. Buka folder ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

Game dimuat dari `app/src/main/assets/index.html` dan tidak membutuhkan internet.
