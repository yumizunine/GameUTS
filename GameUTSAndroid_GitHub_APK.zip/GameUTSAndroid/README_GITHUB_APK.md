# Game Belajar UTS - Build APK dari HP

1. Buat repository GitHub baru, misalnya `GameUTSAndroid`.
2. Upload **isi folder GameUTSAndroid** ke repository (folder `.github` juga harus ikut).
3. Buka tab **Actions**.
4. Pilih workflow **Build APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai proses selesai.
7. Buka hasil workflow yang bertanda centang hijau.
8. Di bagian **Artifacts**, download `GameUTS-APK`.
9. Ekstrak file ZIP hasil download, lalu ambil `app-debug.apk`.
10. Instal APK di HP.

Jika repository menggunakan branch selain `main`, workflow juga tetap bisa dijalankan manual melalui Actions.
